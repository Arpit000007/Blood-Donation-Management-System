package com.example.recommendation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.recommendation.BloodDonor;

import java.util.List;
import java.util.Objects;

@RestController
public class RecommendationController {

    @Autowired
    private RestTemplate restTemplate;

    /**
     * OBSERVER PATTERN
     */
    @GetMapping("/recommendEligibleDonors")
    public ResponseEntity<List<BloodDonor>> fetchEligibleDonors() {
        String url = "http://localhost:4040/api/v1/donors/blooddonor";
        ResponseEntity<List<BloodDonor>> response = restTemplate.exchange(
            url,
            HttpMethod.GET,
            null,
            new ParameterizedTypeReference<List<BloodDonor>>() {}
        );
        for (BloodDonor d: Objects.requireNonNull(response.getBody())) {
            d.notifyDonor();
        }
        return response;
    }
}
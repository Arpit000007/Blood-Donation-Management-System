package com.example.notification.controllers;

import com.example.notification.entity.BloodDonor;
import com.example.notification.entity.DonationCampRegistration;
import com.example.notification.entity.NotificationUsers;
import com.example.notification.services.NotificationService;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import java.util.*;

@RestController
@RequestMapping(path = "/notifications")
@CrossOrigin(origins = "*")
public class NotificationController {

    @Autowired
    private NotificationService service;

    @GetMapping(path = "send/{id}")
    public ResponseEntity<Object> sendNotifications(@PathVariable("id") int id) throws Exception {
        List<DonationCampRegistration> cr = this.service.sendNotificationToRegisteredDonors(id);
        Map<String, Object> responseBody = new HashMap<>();
        if (!cr.isEmpty()) {
            String message = "You have registered for blood donation camp for today at time ";
            Map<String, Object> rs = new HashMap<>();
            rs.put("message", message);
            rs.put("regis", cr);
            return ResponseEntity.ok().body(rs);
        }
        responseBody.put("message", "No Notifications");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseBody);
    }

    @PostMapping(path = "recommend")
    public ResponseEntity<String> recommendNotify(@RequestBody NotificationUsers request) throws Exception {
        List<BloodDonor> donors = request.getDonors();
        String message = request.getMessage();

        // Iterate over the list of donors and send email to each donor
        for (BloodDonor donor : donors) {
            // Assuming the donor object has an email address property
            String email = donor.getEmail(); // Implement this method to extract email from donor object
            System.out.println("Sending " + message + " to " + donor.getEmail());
//            sendEmail(email, message);
            // Send email to the donor
//            sendEmail(email, message);
        }
        return ResponseEntity.ok("Emails sent successfully");
    }

//    private void sendEmail(String email, String msg) {
//        // email ID of Recipient.
//        String recipient = email;
//
//        // email ID of  Sender.
//        String sender = "yatharthagrawal@gmail.com";
//
//        // using host as localhost
//        String host = "127.0.0.1";
//
//        // Getting system properties
//        Properties properties = System.getProperties();
//
//        // Setting up mail server
//        properties.setProperty("mail.smtp.host", host);
//
//        // creating session object to get properties
//        Session session = Session.getDefaultInstance(properties);
//
//        try
//        {
//            // MimeMessage object.
//            MimeMessage message = new MimeMessage(session);
//
//            // Set From Field: adding senders email to from field.
//            message.setFrom(new InternetAddress(sender));
//
//            // Set To Field: adding recipient's email to from field.
//            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
//
//            // Set Subject: subject of the email
//            message.setSubject("Recommended Blood Donation Camps");
//
//            // set body of the email.
//            message.setText(msg);
//
//            // Send email.
//            Transport.send(message);
//            System.out.println("Mail successfully sent");
//        }
//        catch (MessagingException mex)
//        {
//            mex.printStackTrace();
//        }
////        String from = "yatharthagrawal@gmail.com";
////        Properties properties = System.getProperties();
////        properties.setProperty("mail.smtp.host", "smtp.gmail.com"); // Configure SMTP server settings
////        properties.put("mail.smtp.port", "587");
////        properties.put("mail.smtp.auth", "true");
////        properties.put("mail.smtp.starttls.enable", "true");
////        Session session = Session.getDefaultInstance(properties);
////
////        try {
////            MimeMessage mimeMessage = new MimeMessage(session);
////            mimeMessage.setFrom(new InternetAddress(from));
////            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
////            mimeMessage.setSubject("Blood Donation Request");
////            mimeMessage.setText(message);
////            Transport.send(mimeMessage);
////            System.out.println("Sent message successfully to " + email);
////        } catch (MessagingException mex) {
////            mex.printStackTrace();
////        }
//    }
}

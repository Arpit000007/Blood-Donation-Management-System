package com.example.notification.entity;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

public class BloodDonor {

	@Getter
	@Setter
	int donorId;

	@Getter
	@Setter
	String name;

	@Getter
	@Setter
	int age;

	@Getter
	@Setter
	long mobileNumber;

	@Getter
	@Setter
	String gender;

	@Getter
	@Setter
	String bloodGroup;

	@Getter
	@Setter
	String email;

	@Getter
	@Setter
	LocalDate dateOfBirth;

	@Getter
	@Setter
	LocalDate dateOfDonation;

	@Getter
	@Setter
	String address;
}

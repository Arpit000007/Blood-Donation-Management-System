package com.example.notification.services;

import com.example.notification.entity.BloodDonor;
import com.example.notification.entity.DonationCampRegistration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class NotificationService {

    private final RestTemplate restTemplate;

    @Autowired
    public NotificationService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<DonationCampRegistration> fetchBookedSlots(LocalDate date) {
        // URL of the slot booking service
        String url = "http://localhost:4040/api/v3/slots/" + date;

        // Preparing parameters
        Map<String, String> params = new HashMap<>();
        params.put("date", date.toString());

        // Making the GET request
        ResponseEntity<List<DonationCampRegistration>> response = restTemplate.exchange(url, HttpMethod.GET, null, new ParameterizedTypeReference<List<DonationCampRegistration>>() {});
        if (!response.getStatusCode().is2xxSuccessful()) {
            return null;
        }
        // Returning the response body
        return response.getBody();
    }

    public List<DonationCampRegistration> sendNotificationToRegisteredDonors(int id) {
        LocalDate currentDate = LocalDate.now();
        List<DonationCampRegistration> registeredDonors = fetchBookedSlots(currentDate);
        List<DonationCampRegistration> dd = new ArrayList<>();
        if (registeredDonors != null && !registeredDonors.isEmpty()) {
            for (DonationCampRegistration registration : registeredDonors) {
                int idd = registration.getDonorId();
                if (id == registration.getDonorId()) {
                    dd.add(registration);
                }
            }
        }
        return dd;
    }
}
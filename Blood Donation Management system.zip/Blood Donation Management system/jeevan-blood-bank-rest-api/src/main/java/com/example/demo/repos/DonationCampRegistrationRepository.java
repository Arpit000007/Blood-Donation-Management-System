package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.DonationCampRegistration;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface DonationCampRegistrationRepository extends JpaRepository<DonationCampRegistration, Integer> {
    List<DonationCampRegistration> findBySlotTime(LocalDateTime slotTime);

    @Query(value = "SELECT * FROM donation_camp_registration sb WHERE sb.slotTime BETWEEN :start AND :end", nativeQuery = true)
    List<DonationCampRegistration> findBetweenDates(LocalDateTime start, LocalDateTime end);

    @Query(value = "SELECT COUNT(dcr.regId) AS count, d.bloodGroup \n" +
            "FROM blood_bank.donation_camp_registration AS dcr \n" +
            "INNER JOIN blood_bank.donors AS d ON dcr.donorId = d.donorId \n" +
            "GROUP BY d.bloodGroup;", nativeQuery = true)
    List<Object> getCountOfGroups();
}

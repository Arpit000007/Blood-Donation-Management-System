package com.example.demo.entity;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity
@Table(name = "donors")
@Data
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class BloodDonor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int donorId;
	String name;
	int age;
	long mobileNumber;
	String gender;
	String bloodGroup;

	@Column(unique = true)
	String email;
	LocalDate dateOfBirth;
	LocalDate dateOfDonation;
	String address;
	String password;
}

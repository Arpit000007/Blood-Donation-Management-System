package com.example.Jeevanblackboard.controller;

import org.springframework.stereotype.Component;

@Component
public interface IKnowledgeSource {
//    public void handleData(BlackBoard blackboard);
}
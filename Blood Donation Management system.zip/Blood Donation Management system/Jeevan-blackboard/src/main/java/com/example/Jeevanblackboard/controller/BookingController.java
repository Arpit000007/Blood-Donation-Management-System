package com.example.Jeevanblackboard.controller;

import com.example.Jeevanblackboard.BlackBoard;
import com.example.Jeevanblackboard.entity.BloodDonor;
import com.example.Jeevanblackboard.entity.DonationCamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookingController implements IKnowledgeSource {

    BlackBoard blackboard;
    public BookingController(BlackBoard blackboard){
        this.blackboard = blackboard;
    }

    @PostMapping(path = "donors")
    public BloodDonor saveDonor(@RequestBody BloodDonor donor) throws Exception {
        BloodDonor responseDonor = this.blackboard.saveDonor(donor);
        if(responseDonor == null) {
            throw new Exception();
        } else {
            return responseDonor;
        }
    }

    @GetMapping(path = "login")
    public BloodDonor loginDonor(@RequestParam("username") String username, @RequestParam("password") String password) {
        return this.blackboard.findDonorByUsernameAndPassword(username, password);
    }

    @GetMapping(path = "donors/{id}")
    public BloodDonor findByDonorId(@PathVariable("id") int id) throws Exception {
        BloodDonor donor = this.blackboard.getDonorById(id);
        if(donor == null) {
            throw new Exception();
        } else {
            return donor;
        }
    }

    // To find all donors available
    @GetMapping(path = "donors")
    public List<BloodDonor> findDonors() throws Exception{
        List<BloodDonor> list = this.blackboard.findAllDonors();
        if(list.isEmpty()) {
            throw new Exception();
        } else {
            return list;
        }
    }

    // To find all eligible donors
    @GetMapping(path = "donors/blooddonor")
    public List<BloodDonor> findEligibleDonor() throws Exception{
        List<BloodDonor> list = this.blackboard.findAllEligibleDonors();
        if(list.isEmpty()) {
            throw new Exception();
        } else {
            return list;
        }
    }

    // To find eligible donors by group
    @GetMapping(path = "/donors/blooddonor/{group}")
    public List<BloodDonor> findEligibleDonorsByGroup(@PathVariable("group") String group) throws Exception{
        List<BloodDonor> list = this.blackboard.findAllEligibleDonorsByGroup(group);
        if(list.isEmpty()) {
            throw new Exception();
        } else {
            return list;
        }
    }

    // To find donors by location
    @GetMapping(path = "donors/location/{location}")
    public List<BloodDonor> findDonorByLocation(@PathVariable("location") String address) throws Exception{
        List<BloodDonor> list = this.blackboard.findAllEligibleDonorsByLocation(address);
        if(list.isEmpty()) {
            throw new Exception();
        } else {
            return list;
        }
    }

    // To find donors by group
    @GetMapping(path = "donors/group/{group}")
    public List<BloodDonor> findDonorsByGroup(@PathVariable("group") String group) throws Exception{
        List<BloodDonor> list =  this.blackboard.findByBloodGroup(group);
        if(list.isEmpty()) {
            throw new Exception();
        } else {
            return list;
        }
    }

    // To update the donor in the database
    @PutMapping(path = "donors/{id}")
    public ResponseEntity<String> updateDonor(@PathVariable("id") int id, @RequestBody BloodDonor donor) throws Exception{

        int rowsUpdated = this.blackboard.updateDonor(id,donor);

        if(rowsUpdated > 0) {
            String message = "Information Updated";
            return ResponseEntity.ok().body(message);
        }
        else {
            throw new Exception();
        }
    }

    // To delete the donor from the database
    @DeleteMapping(path = "donors/{id}")
    public ResponseEntity<String> deleteDonor(@PathVariable("id") int id) throws Exception{
        String message = null;

        boolean deleted = this.blackboard.removeDonor(id);
        if(deleted) {
            message = "Donor Removed Successfully";
            return ResponseEntity.ok().body(message);
        } else {
            System.out.println("Not deleted");
            throw new Exception();
        }
    }

    @PostMapping(path = "camps")
    public ResponseEntity<Object> saveCamp(@RequestBody DonationCamp camp) throws Exception {
        DonationCamp responseDonor = this.blackboard.saveCamp(camp);
        System.out.println("camps: " + responseDonor);
        if(responseDonor == null) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to register Camp");
        } else {
            return ResponseEntity.status(HttpStatus.CREATED).body("Camp registered");
        }
    }
}
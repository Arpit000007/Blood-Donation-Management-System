package com.example.Jeevanblackboard.controller;

import com.example.Jeevanblackboard.BlackBoard;
import com.example.Jeevanblackboard.entity.DonationCampRegistration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@RestController
public class CampRegistrationController {

    BlackBoard blackboard;
    public CampRegistrationController(BlackBoard blackboard){
        this.blackboard = blackboard;
    }

    @PostMapping(path = "donorCamp")
    public ResponseEntity<Object> registerDonor(@RequestBody DonationCampRegistration registration) {
        try {
            DonationCampRegistration registrationResponse = this.blackboard.registerDonorForCamp(registration);
            return ResponseEntity.status(HttpStatus.CREATED).body("Donor registered successfully! Registration ID: " + registrationResponse.getRegId());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to register donor: " + e.getMessage());
        }
    }

    @GetMapping(path = "slots/{date}")
    public ResponseEntity<List<DonationCampRegistration>> getBookingsByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);

        List<DonationCampRegistration> bookings = this.blackboard.getBookingsByDate(date);

        if (bookings.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(bookings);
        }

        return ResponseEntity.ok(bookings);
    }
}

package com.example.Jeevanblackboard.controller;

import com.example.Jeevanblackboard.BlackBoard;
import com.example.Jeevanblackboard.entity.BloodDonor;
import com.example.Jeevanblackboard.entity.DonationCampRegistration;
import com.example.Jeevanblackboard.entity.NotificationUsers;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping(path = "/notifications")
public class NotificationController {

    BlackBoard blackboard;
    public NotificationController(BlackBoard blackboard){
        this.blackboard = blackboard;
    }

    @PostMapping(path = "recommend")
    public ResponseEntity<String> recommendNotify(@RequestBody NotificationUsers request) throws Exception {
        List<BloodDonor> donors = request.getDonors();
        String message = request.getMessage();
        this.blackboard.recommendationNotification(donors, message);
//        // Iterate over the list of donors and send email to each donor
//        for (BloodDonor donor : donors) {
//            // Assuming the donor object has an email address property
//            String email = donor.getEmail(); // Implement this method to extract email from donor object
//            System.out.println("Sending " + message + " to " + donor.getEmail());
//            // Send email to the donor
////            sendEmail(email, message);
//        }
        return ResponseEntity.ok("Emails sent successfully");
    }

    @GetMapping(path = "/send/{id}") // Corrected path syntax
    public ResponseEntity<String> sendNotifications(@PathVariable("id") int id) {
        try {
            DonationCampRegistration d = this.blackboard.sendNotificationToRegisteredDonors(LocalDate.now(), id);
            if (d != null) {
                System.out.println("success");
                String message = "Notification sent";
                return ResponseEntity.ok().body(message);
            } else {
                System.out.println("fail");
                return ResponseEntity.notFound().build(); // Using build() for not found response
            }
        } catch (Exception e) {
            System.out.println("failed");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred"); // Handling exceptions
        }
    }
}

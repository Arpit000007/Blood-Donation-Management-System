package com.example.Jeevanblackboard;

import com.example.Jeevanblackboard.controller.IKnowledgeSource;
import com.example.Jeevanblackboard.BlackBoard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
@Component
public class ControlComponent {

    @Autowired
    private List<IKnowledgeSource> knowledgeSources;

    @Autowired
    private BlackBoard blackboard;

    public ControlComponent() {
//        this.knowledgeSources = new ArrayList<>();
//        this.blackboard =
    }

    public void addKnowledgeSource(IKnowledgeSource knowledgeSource) {
        knowledgeSources.add(knowledgeSource);
    }

//    public void runAnalysis() {
//        for (IKnowledgeSource ks : knowledgeSources) {
//            ks.analyzeData(blackboard);
//        }
//    }

    public BlackBoard getBlackboard() {
        return blackboard;
    }
}
